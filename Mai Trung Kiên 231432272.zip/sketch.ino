
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHTesp.h>

// ================= WIFI =================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ================= MQTT =================
const char* mqtt_server = "broker.emqx.io";
const int mqtt_port = 1883;

const char* TOPIC_TELEMETRY = "utc/firelab/telemetry";
const char* TOPIC_FAN = "utc/firelab/fan/set";
const char* TOPIC_PUMP = "utc/firelab/pump/set";

// ================= GPIO =================
#define MQ2_PIN       34
#define DHT_PIN       15
#define FAN_PIN       18
#define PUMP_PIN       5
#define ALARM_LED_PIN 23
#define BUZZER_PIN    19

// ================= NGUONG CANH BAO =================
// Gia tri minh hoa de thu nghiem, can hieu chinh
// theo cam bien va dieu kien thuc te.
const int GAS_THRESHOLD = 1800;
const float TEMP_THRESHOLD = 40.0;

// ================= DOI TUONG =================
WiFiClient espClient;
PubSubClient client(espClient);
DHTesp dht;

// ================= TRANG THAI =================
bool manualFan = false;
bool manualPump = false;

bool fanOn = false;
bool pumpOn = false;
bool alarmOn = false;

unsigned long lastPublish = 0;
const unsigned long PUBLISH_INTERVAL = 2000;

// ================= NHAN LENH MQTT =================
void callback(char* topic, byte* payload,
              unsigned int length) {
  String topicName = String(topic);
  String message = "";

  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  message.trim();
  message.toUpperCase();

  Serial.print("MQTT topic: ");
  Serial.println(topicName);
  Serial.print("Payload: ");
  Serial.println(message);

  if (topicName == TOPIC_FAN) {
    if (message == "ON") {
      manualFan = true;
    } else if (message == "OFF") {
      manualFan = false;
    }
  }

  if (topicName == TOPIC_PUMP) {
    if (message == "ON") {
      manualPump = true;
    } else if (message == "OFF") {
      manualPump = false;
    }
  }
}

// ================= KET NOI WIFI =================
void connectWiFi() {
  Serial.println();
  Serial.print("Connecting WiFi: ");
  Serial.println(ssid);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connected");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

// ================= KET NOI MQTT =================
void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    // Doi client ID rieng cho thiet bi
    String clientId = "ESP32-FireAlarm-" +
                      String((uint32_t)ESP.getEfuseMac(), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("MQTT connected");

      client.subscribe(TOPIC_FAN);
      client.subscribe(TOPIC_PUMP);

      Serial.println("Subscribed to fan/set and pump/set");
    } else {
      Serial.print("Failed, state = ");
      Serial.println(client.state());
      Serial.println("Retry after 2 seconds");
      delay(2000);
    }
  }
}

// ================= DIEU KHIEN THIET BI =================
void updateOutputs(bool gasDanger, bool tempDanger) {
  // Dieu khien tu dong duoc uu tien khi co canh bao
  fanOn = gasDanger || manualFan;
  pumpOn = tempDanger || manualPump;
  alarmOn = gasDanger || tempDanger;

  digitalWrite(FAN_PIN, fanOn ? HIGH : LOW);
  digitalWrite(PUMP_PIN, pumpOn ? HIGH : LOW);
  digitalWrite(ALARM_LED_PIN, alarmOn ? HIGH : LOW);

  if (alarmOn) {
    tone(BUZZER_PIN, 2000);
  } else {
    noTone(BUZZER_PIN);
  }
}

// ================= GUI TELEMETRY =================
void publishTelemetry(float temperature, int gasValue) {
  char json[180];

  snprintf(
    json,
    sizeof(json),
    "{\"temperature\":%.2f,\"gas\":%d,"
    "\"fan\":%d,\"pump\":%d,\"alarm\":%d}",
    temperature,
    gasValue,
    fanOn ? 1 : 0,
    pumpOn ? 1 : 0,
    alarmOn ? 1 : 0
  );

  if (client.publish(TOPIC_TELEMETRY, json)) {
    Serial.print("Telemetry sent: ");
    Serial.println(json);
  } else {
    Serial.println("Telemetry publish failed");
  }
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);

  pinMode(MQ2_PIN, INPUT);
  pinMode(FAN_PIN, OUTPUT);
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(ALARM_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(FAN_PIN, LOW);
  digitalWrite(PUMP_PIN, LOW);
  digitalWrite(ALARM_LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  dht.setup(DHT_PIN, DHTesp::DHT22);

  connectWiFi();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
  client.setBufferSize(256);
}

// ================= LOOP =================
void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  if (!client.connected()) {
    reconnectMQTT();
  }

  client.loop();

  // Doc cam bien
  int gasValue = analogRead(MQ2_PIN);
  TempAndHumidity data = dht.getTempAndHumidity();

  // Tranh xu ly neu DHT22 chua co du lieu hop le
  if (isnan(data.temperature)) {
    Serial.println("DHT22 read error");
    delay(500);
    return;
  }

  float temperature = data.temperature;

  bool gasDanger = gasValue >= GAS_THRESHOLD;
  bool tempDanger = temperature >= TEMP_THRESHOLD;

  updateOutputs(gasDanger, tempDanger);

  // In thong tin ra Serial Monitor
  Serial.print("Gas: ");
  Serial.print(gasValue);
  Serial.print(" | Temperature: ");
  Serial.print(temperature);
  Serial.print(" C | Fan: ");
  Serial.print(fanOn ? "ON" : "OFF");
  Serial.print(" | Pump: ");
  Serial.print(pumpOn ? "ON" : "OFF");
  Serial.print(" | Alarm: ");
  Serial.println(alarmOn ? "ON" : "OFF");

  // Gui telemetry moi 2 giay
  if (millis() - lastPublish >= PUBLISH_INTERVAL) {
    lastPublish = millis();
    publishTelemetry(temperature, gasValue);
  }

  delay(2000);
}

